
const country = "India";
const continent = "Asia";
var population = 34;
const isIsland = false;
const language = "English";

/* console.log('Half of the population : ' + population / 2);
console.log(population + 1);
console.log(`Population > 6 million : ${population > 6}`);

var description = country + " is in " + continent + " and its " + population +
    " million people speaks " + language;
console.log(description); */

// Using Templet Literals
/* var description = `${country} is in ${continent} and its ${population} million people speaks ${language} `;
console.log(description); */

/* 
if (population > 33) {
    console.log(`${country} population is above above avearage`);
} else {
    console.log(`${country} population is ${33 - population} million below average`)
} */


/* console.log('9' - '5'); //4
console.log('19' - '13' + '17'); //617
console.log('19' - '13' + 17);//23
console.log('123' < 57); //false
console.log(5 + 6 + '4' + 9 - 4 - 2); //1143 */

/* var numNeighbours = prompt('How many neighbour countries does your country have?');

if (numNeighbours === '1') {
    console.log('Only 1 border');
} else if (numNeighbours > 1) {
    console.log('More than 1 border');
} else {
    console.log('No borders');
}
 */


/* if(language == 'English' && population < 50 && !isIsland){
    console.log(` You should live in ${country}`);
}else {
    console.log(`${country} does not meet your criteria`);
}
 */


/* switch (prompt("Enter thr language name here :")) {
    case 'chines':
    case 'mandarin':
        console.log('MOST number of native speakers!');
        break;
    case 'spanish':
        console.log('2nd place in number of native speakers');
        break;
    case 'english':
        console.log('3rd place');
        break;
    case 'hindi':
        console.log('Number 4')
        break;
    case 'arabic':
        console.log('%th most spoken language');
        break;
    default:
        console.log('Greate language too');
        break;
} */

//Ternary operator in Java script

/* population > 33 ? console.log(`${country}'s population is above average'`) : console.log(`${country}'s population is below average`);

console.log(`${country}'s population is ${population > 33 ? 'above' : 'below'} average`); */

/* function describeCountry(country, population, capacity) {
    console.log(`${country} has ${population} million people and its capital city is ${capacity}`)
}

describeCountry('India',100,'Delhi');
describeCountry('USA',50,'washington');
describeCountry('Chaina',150,'Beijing');
 */
/* The world population is 7900 million people. Create a function declaration
called 'percentageOfWorld1' which receives a 'population' value, and
returns the percentage of the world population that the given population
represents. For example, China has 1441 million people, so it's about 18.2% of
the world population */

/* 
// Function declaration
function percentageOfWorld1(population){
    return population/7900 * 100;    
}

console.log(Math.round(percentageOfWorld1(6000)));

// Function expression 

const percentageOfWorld2 = function (population){
    return population/7900 * 100;  
}

console.log(Math.round(percentageOfWorld2(6500))); */

// Arrow function 


/* percentageOfWorld3 = (population) => population/7900 * 100;
console.log(Math.round(percentageOfWorld3(6000))); */



/*  var percentageOfWorld3 =  (population) => population/7900 * 100;
console.log(Math.round(percentageOfWorld3(6900)));
 


var percent = population => Math.round(population/7900*100);

function describePopulation(country,population){
    return `${country} has ${population} million people which is about ${percent(population)} % of the world`;
}

console.log(describePopulation('India',6900)); */


/* 
var populations = [6000, 2333, 3232, 2239, 5230];
console.log(populations[4]);
var percentages = [];

function percent(count) {
    return Math.round(count / 7900 * 100);
}

for (let i=0; i < populations.length; i++) {
    percentages.push(percent(populations[i]));
}
console.log(percentages);
 */


/* var neighbours = ['India', 'Pakistan', 'China', 'Afganistan', 'Bhutan'];

if (!neighbours.includes('Germani')) {
    console.log('Probably not a central European country');
} else {
    console.log('Neighbouring part of India');
}

neighbours[neighbours.indexOf('China')] = 'Republic of china';
console.log(neighbours); */


let myCountry = {
    'country': 'India',
    'capital': 'Delhi',
    'language': 'Telugu',
    'population': 130,
    'neighbours': ['India', 'Pakistan', 'China', 'Afganistan', 'Bhutan']

}

/* console.log(`${myCountry.country} has ${myCountry.population} Inidan people, 3 neighbouring countries 
and a capital called ${myCountry.country}.`);

myCountry.population += 2;
console.log(myCountry.population); */
